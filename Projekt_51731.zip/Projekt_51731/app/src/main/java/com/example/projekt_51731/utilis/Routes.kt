package com.example.projekt_51731.utilis

object Routes {
    val homepage = "home_page"
    val loginPage = "login_page"
    val registerPage = "register_page"
}